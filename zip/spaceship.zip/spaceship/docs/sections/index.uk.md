# Вбудовані секції

<div>
  <input
    id="sections-search"
    data-registry="internal"
    class="md-input md-input--stretch"
    placeholder="Шукати розділи за ім'ям або описом"
  >
  <ol id="sections-list">
    <!-- Search results -->
  </ol>
</div>
