# Built-in sections

<div>
  <input
    id="sections-search"
    data-registry="internal"
    class="md-input md-input--stretch"
    placeholder="Search sections by name or description"
  >
  <ol id="sections-list">
    <!-- Search results -->
  </ol>
</div>
