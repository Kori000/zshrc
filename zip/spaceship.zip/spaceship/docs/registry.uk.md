---
hide:
  - navigation
  - toc
---

# Реєстр Секцій

Тут ви можете знайти вбудовані та користувацькі секції. Додавайте нові секції [роблячи внески у реєстр](https://github.com/spaceship-prompt/spaceship-prompt/blob/master/docs/registry/external.json).

---

<div>
  <input
    id="sections-search"
    class="md-input md-input--stretch"
    placeholder="Пошук розділів за назвою, описом або типом"
  >
  <ol id="sections-list">
  </ol>
</div>
